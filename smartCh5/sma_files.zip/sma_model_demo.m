
%
%      sma_model_demo.m
%

  m=matparam(1);
  c=comparam(m);
  [sig,ep,T,xm,xp,tspan] = polycryst(0:400,input_Te(0),m,c);

%
% 




